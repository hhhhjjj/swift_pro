import UIKit

let 矩形 = CGRect(x: 0, y: 0, width: 200, height: 50)
let 订购按钮 = UILabel(frame: 矩形)

订购按钮.text = "立即订购"
订购按钮.textColor = .white
订购按钮.backgroundColor = .purple
订购按钮.textAlignment = .center
订购按钮.layer.cornerRadius = 10
订购按钮.clipsToBounds = true
//点击右侧的方块就能看到这个按钮现在长什么样子
