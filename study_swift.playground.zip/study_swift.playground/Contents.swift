import UIKit
//这个是在xcode里面来运行
var str = "xcode新建playground"
print(str)

//注意中英文切换
class 车{
    var 轮子 = 0
    var 描述:String {
        return "\(轮子)个轮子"
    }
}

let 我的车 = 车()

class 自行车:车 {
//    重写父类构造函数
    override init() {
        super.init()
        轮子 = 2
    }
}

let 我的自行车 = 自行车()
print("我的自行车轮子：\(我的自行车.轮子)个")
